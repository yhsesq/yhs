#define COMPRESS_ID		7

#define DDBITS			2
#define CLEVEL			3
#include "compr1b.h"

