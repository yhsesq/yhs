#define COMPRESS_ID		3

#define DDBITS			0
#define CLEVEL			3
#include "compr1c.h"

