NOTE:
=====

All build scripts, executables and DLLs should work
under both Windows 95 and Windows NT, and probably also
under Windows 3.1 + Win32s.

For best performance I recommend using Watcom C.

