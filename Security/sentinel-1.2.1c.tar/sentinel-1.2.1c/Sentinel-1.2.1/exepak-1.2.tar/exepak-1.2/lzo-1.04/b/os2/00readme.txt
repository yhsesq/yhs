NOTE:
=====

OS/2 support is completely UNTESTED.
Please send me your build files.

