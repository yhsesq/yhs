NOTE:
=====

The 16-bit Windows version is pretty slow.

Use the 32-bit Windows version whenever possible (it should also
work under Windows 3.1 + Win32s) because it is *much* faster.

